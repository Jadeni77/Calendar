package calendar.model.enumclass;

/**
 * Enum representing the status of a calendar event.
 */
public enum EventStatus {
    PUBLIC, PRIVATE
}
